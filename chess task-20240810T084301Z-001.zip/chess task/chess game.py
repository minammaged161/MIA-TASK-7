import pygame
import sys
import random

pygame.init()

WIDTH, HEIGHT = 800, 800
SQUARE_SIZE = WIDTH // 8
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Chess Game")

def load_images():
    pieces = ['pawn', 'rook', 'knight', 'bishop', 'queen', 'king']
    images = {}
    for piece in pieces:
        for color in ['white', 'black']:
            img = pygame.image.load(f'images/{color}_{piece}.png')
            img = pygame.transform.scale(img, (SQUARE_SIZE, SQUARE_SIZE))
            images[f'{color}_{piece}'] = img
    return images

class ChessPiece:
    def __init__(self, color, position):
        self.color = color
        self.position = position

    def move(self, new_position):
        self.position = new_position

    def valid_moves(self, board):
        raise NotImplementedError("This method should be implemented by subclasses.")

class Pawn(ChessPiece):
    def valid_moves(self, board):
        row, col = self.position
        direction = 1 if self.color == 'white' else -1
        moves = []
        if 0 <= row + direction < 8 and not board.board[row + direction][col]:
            moves.append((row + direction, col))
        for d in [-1, 1]:
            if 0 <= row + direction < 8 and 0 <= col + d < 8:
                target = board.board[row + direction][col + d]
                if target and target.color != self.color:
                    moves.append((row + direction, col + d))
        return moves

class Rook(ChessPiece):
    def valid_moves(self, board):
        row, col = self.position
        moves = []
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        for dr, dc in directions:
            r, c = row, col
            while True:
                r += dr
                c += dc
                if 0 <= r < 8 and 0 <= c < 8:
                    if board.board[r][c]:
                        if board.board[r][c].color != self.color:
                            moves.append((r, c))
                        break
                    moves.append((r, c))
                else:
                    break
        return moves

class Knight(ChessPiece):
    def valid_moves(self, board):
        row, col = self.position
        moves = []
        directions = [(2, 1), (2, -1), (-2, 1), (-2, -1), (1, 2), (1, -2), (-1, 2), (-1, -2)]
        for dr, dc in directions:
            r, c = row + dr, col + dc
            if 0 <= r < 8 and 0 <= c < 8:
                if board.board[r][c] is None or board.board[r][c].color != self.color:
                    moves.append((r, c))
        return moves

class Bishop(ChessPiece):
    def valid_moves(self, board):
        row, col = self.position
        moves = []
        directions = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
        for dr, dc in directions:
            r, c = row, col
            while True:
                r += dr
                c += dc
                if 0 <= r < 8 and 0 <= c < 8:
                    if board.board[r][c]:
                        if board.board[r][c].color != self.color:
                            moves.append((r, c))
                        break
                    moves.append((r, c))
                else:
                    break
        return moves

class Queen(ChessPiece):
    def valid_moves(self, board):
        row, col = self.position
        moves = []
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]
        for dr, dc in directions:
            r, c = row, col
            while True:
                r += dr
                c += dc
                if 0 <= r < 8 and 0 <= c < 8:
                    if board.board[r][c]:
                        if board.board[r][c].color != self.color:
                            moves.append((r, c))
                        break
                    moves.append((r, c))
                else:
                    break
        return moves

class King(ChessPiece):
    def valid_moves(self, board):
        row, col = self.position
        moves = []
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]
        for dr, dc in directions:
            r, c = row + dr, col + dc
            if 0 <= r < 8 and 0 <= c < 8:
                if board.board[r][c] is None or board.board[r][c].color != self.color:
                    moves.append((r, c))
        return moves

class ChessBoard:
    def __init__(self):
        self.board = self.initialize_board()
        self.current_turn = 'white'

    def initialize_board(self):
        board = [[None for _ in range(8)] for _ in range(8)]
        board[0] = [Rook('white', (0, 0)), Knight('white', (0, 1)), Bishop('white', (0, 2)), Queen('white', (0, 3)),
                    King('white', (0, 4)), Bishop('white', (0, 5)), Knight('white', (0, 6)), Rook('white', (0, 7))]
        board[1] = [Pawn('white', (1, i)) for i in range(8)]
        board[6] = [Pawn('black', (6, i)) for i in range(8)]
        board[7] = [Rook('black', (7, 0)), Knight('black', (7, 1)), Bishop('black', (7, 2)), Queen('black', (7, 3)),
                    King('black', (7, 4)), Bishop('black', (7, 5)), Knight('black', (7, 6)), Rook('black', (7, 7))]
        return board

    def switch_turn(self):
        self.current_turn = 'black' if self.current_turn == 'white' else 'white'

    def move_piece(self, start_pos, end_pos):
        piece = self.board[start_pos[0]][start_pos[1]]
        if piece and piece.color == self.current_turn:
            valid_moves = piece.valid_moves(self)
            if end_pos in valid_moves:
                self.board[end_pos[0]][end_pos[1]] = piece
                self.board[start_pos[0]][start_pos[1]] = None
                piece.move(end_pos)
                self.switch_turn()

    def ai_move(self):
        all_moves = []
        for row in range(8):
            for col in range(8):
                piece = self.board[row][col]
                if piece and piece.color == self.current_turn:
                    moves = piece.valid_moves(self)
                    for move in moves:
                        all_moves.append((piece.position, move))
        if all_moves:
            start_pos, end_pos = random.choice(all_moves)
            self.move_piece(start_pos, end_pos)

def draw_board(turn):
    colors = [WHITE, BLACK]
    for row in range(8):
        for col in range(8):
            color = colors[(row + col) % 2] if turn == 'white' else colors[(7 - row + 7 - col) % 2]
            pygame.draw.rect(screen, color, (col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))

def draw_pieces(board, images, turn):
    for row in range(8):
        for col in range(8):
            piece = board[row][col]
            if piece:
                img = images[f'{piece.color}_{type(piece).__name__.lower()}']
                if turn == 'black':
                    img = pygame.transform.flip(img, True, False)
                screen.blit(img, (col * SQUARE_SIZE, row * SQUARE_SIZE))

def main():
    images = load_images()
    clock = pygame.time.Clock()
    board = ChessBoard()
    selected_piece = None
    valid_moves = []
    running = True
    single_player_mode = True

    while running:
        draw_board(board.current_turn)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                row, col = y // SQUARE_SIZE, x // SQUARE_SIZE

                if selected_piece:
                    if (row, col) in valid_moves:
                        board.move_piece(selected_piece.position, (row, col))
                        selected_piece = None
                        valid_moves = []
                        if single_player_mode and board.current_turn == 'black':
                            board.ai_move()
                    else:
                        selected_piece = None
                        valid_moves = []
                else:
                    piece = board.board[row][col]
                    if piece and piece.color == board.current_turn:
                        selected_piece = piece
                        valid_moves = piece.valid_moves(board)

        for move in valid_moves:
            pygame.draw.rect(screen, RED, (move[1] * SQUARE_SIZE, move[0] * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE), 5)

        draw_pieces(board.board, images, board.current_turn)

        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()
